<?php
//calculator_test1.php
include 'Calculator.php';


$myCalc = new Calculator();

echo $myCalc->add(2,2);